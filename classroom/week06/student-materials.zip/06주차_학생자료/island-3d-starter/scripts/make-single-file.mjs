import fs from 'node:fs/promises'
import path from 'node:path'
const root=process.cwd()
const dist=path.join(root,'dist')
let html=await fs.readFile(path.join(dist,'index.html'),'utf8')
const scriptMatches=[...html.matchAll(/<script\b[^>]*\bsrc="([^"]+)"[^>]*><\/script>/g)]
if(scriptMatches.length!==1)throw new Error('Expected one bundled JavaScript entry')
for(const match of scriptMatches){
  const code=await fs.readFile(path.join(dist,match[1]),'utf8')
  if(/\bimport\s*\(/.test(code))throw new Error('Dynamic imports remain; cannot create standalone HTML')
  html=html.replace(match[0],()=>'<script type="module">'+code.replace(/<\/script/gi,'<\\/script')+'</script>')
}
for(const match of [...html.matchAll(/<link\b[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g)]){
  const css=await fs.readFile(path.join(dist,match[1]),'utf8')
  html=html.replace(match[0],()=>'<style>'+css+'</style>')
}
const markup=html.replace(/<script type="module">[\s\S]*?<\/script>/g,'')
if(/<script\b[^>]*\bsrc=|<link\b[^>]*rel="stylesheet"[^>]*href=/.test(markup))throw new Error('External entry asset remains')
const output=path.join(dist,'island-starter-standalone.html')
await fs.writeFile(output,html)
console.log('Standalone build: '+output)
console.log('The studio Environment preset still requests a remote HDR; fallback lights work without it.')
