import { BufferGeometry, Float32BufferAttribute, Color } from 'three'

// 고정된 수식으로 만든 지형. 새로고침해도 동일한 섬을 비교할 수 있다.
// 완성된 모델 파일, 높이맵 이미지, 무작위 외부 자산을 불러오지 않는다.
export function terrainHeight(x: number, z: number) {
  const dx = (x + .62) / 1.43
  const dz = (z + .57) / 1.27
  const r = Math.sqrt(dx * dx + dz * dz)
  const peak = Math.exp(-((dx + .2) ** 2 * 2.5 + (dz + .17) ** 2 * 2.1))
  return .50 + Math.max(0, 1 - r) * .7 + peak * .8
}

export function createIslandGeometry() {
  const positions: number[] = [], colors: number[] = [], indices: number[] = []
  const segments = 72, rings = 22
  const sand = new Color('#d8c798'), grass = new Color('#789167'), rock = new Color('#777e70')
  for (let ring = 0; ring <= rings; ring++) {
    const radius = ring / rings
    for (let i = 0; i <= segments; i++) {
      const angle = i / segments * Math.PI * 2
      const edge = 1 + .06 * Math.sin(angle * 3 + .7) + .04 * Math.cos(angle * 5)
      const x = -.62 + Math.cos(angle) * 1.43 * radius * edge
      const z = -.57 + Math.sin(angle) * 1.27 * radius * edge
      const height = terrainHeight(x, z)
      const y = height + Math.sin(x * 5.2 + z * 2.7) * .035 * (1 - radius)
      positions.push(x, y, z)
      const color = y < .81 ? sand : y > 1.50 ? rock : grass
      colors.push(color.r, color.g, color.b)
      if (ring < rings && i < segments) {
        const a = ring * (segments + 1) + i, b = a + segments + 1
        indices.push(a, b + 1, b, a, a + 1, b + 1)
      }
    }
  }
  const edgeStart = rings * (segments + 1)
  for (let i = 0; i <= segments; i++) {
    const topIndex = edgeStart + i
    positions.push(positions[topIndex * 3], -.51, positions[topIndex * 3 + 2])
    colors.push(rock.r, rock.g, rock.b)
    if (i < segments) {
      const bottom = (rings + 1) * (segments + 1) + i
      indices.push(topIndex, bottom, topIndex + 1, topIndex + 1, bottom, bottom + 1)
    }
  }
  const geometry = new BufferGeometry()
  geometry.setAttribute('position', new Float32BufferAttribute(positions, 3))
  geometry.setAttribute('color', new Float32BufferAttribute(colors, 3))
  geometry.setIndex(indices)
  geometry.computeVertexNormals()
  return geometry
}

export const ROCKS: [number, number, number, number][] = [
  [1.13, .45, .82, .26], [1.48, .40, .31, .17], [.91, .46, 1.27, .23],
  [-1.64, .63, .65, .30], [-1.87, .4, 1.01, .18], [.37, .63, -1.61, .33],
  [.72, -.02, -.97, .20], [1.39, -.14, 1.55, .18], [-.48, -.22, 1.71, .22],
]

export const TREES: [number, number, number][] = [
  [-1.23, -.25, .72], [-1.03, .07, .62], [-.88, .39, .54], [-.55, .37, .70],
  [-.26, .11, .62], [.15, -.35, .75], [.27, -.68, .64], [-.08, -1.12, .66],
  [-.41, -1.38, .56], [-1.10, -1.02, .62], [-1.55, -.67, .55],
]
