import { Component, Suspense, useCallback, useEffect, useMemo, useState } from 'react'
import type { ErrorInfo, ReactNode } from 'react'
import { Canvas } from '@react-three/fiber'
import { Environment, MeshTransmissionMaterial, OrbitControls, RoundedBox } from '@react-three/drei'
import { Leva, useControls } from 'leva'
import { createIslandGeometry, ROCKS, terrainHeight, TREES } from './terrain'

const PALETTES = [
  { name: '청록색', hex: '#5fbab2' },
  { name: '푸른색', hex: '#6badd1' },
  { name: '에메랄드색', hex: '#77bb98' },
]

class EnvironmentBoundary extends Component<{ children: ReactNode; onError: () => void }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  componentDidCatch(_error: Error, _info: ErrorInfo) { this.props.onError() }
  render() { return this.state.failed ? null : this.props.children }
}

class SceneBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  render() {
    return this.state.failed ? <div className="canvas-fallback"><h2>3D 화면을 열지 못했어요</h2><p>브라우저를 새로고침하고 하드웨어 가속과 WebGL 지원을 확인하기.</p><p>교사에게 현재 화면과 오류 메시지 보여주기.</p></div> : this.props.children
  }
}

function EnvironmentReady({ onReady }: { onReady: () => void }) {
  useEffect(onReady, [onReady])
  return null
}

function Island() {
  const geometry = useMemo(createIslandGeometry, [])
  useEffect(() => () => geometry.dispose(), [geometry])
  return <group>
    <mesh geometry={geometry} castShadow receiveShadow><meshStandardMaterial vertexColors roughness={.96} /></mesh>
    {ROCKS.map(([x, y, z, size], index) => <mesh key={'rock-' + index} position={[x, y, z]} rotation={[.2 * index, .7 * index, .1]} scale={[size * 1.2, size, size * .83]} castShadow receiveShadow><dodecahedronGeometry args={[1, 0]} /><meshStandardMaterial color={index % 2 ? '#a4a99a' : '#79857c'} roughness={1} /></mesh>)}
    {TREES.map(([x, z, size], index) => <group key={'tree-' + index} position={[x, terrainHeight(x, z) - .01, z]} scale={size}>
      <mesh position={[0, .14, 0]} castShadow><cylinderGeometry args={[.036, .046, .29, 6]} /><meshStandardMaterial color="#8b795d" /></mesh>
      <mesh position={[0, .41, 0]} castShadow><coneGeometry args={[.22, .6, 7]} /><meshStandardMaterial color={index % 2 ? '#41634d' : '#52795b'} roughness={.9} /></mesh>
      <mesh position={[0, .63, 0]} castShadow><coneGeometry args={[.16, .43, 7]} /><meshStandardMaterial color="#648164" roughness={.95} /></mesh>
    </group>)}
  </group>
}

function Scene({ waterColor, environmentEnabled, onReady, onError }: { waterColor: string; environmentEnabled: boolean; onReady: () => void; onError: () => void }) {
  return <>
    <color attach="background" args={['#eeeae0']} />
    {/* 프리셋을 못 불러와도 아래 기본 조명과 섬은 남는다. */}
    <ambientLight intensity={.9} />
    <directionalLight position={[-3, 7, 5]} intensity={2.5} castShadow shadow-mapSize={[1024, 1024]} shadow-camera-left={-4} shadow-camera-right={4} shadow-camera-top={4} shadow-camera-bottom={-4} shadow-bias={-.0005} />
    {environmentEnabled && <EnvironmentBoundary onError={onError}><Suspense fallback={null}>
      {/* studio 프리셋은 외부 CDN HDR 파일을 사용한다. 로컬 모델 파일은 없다. */}
      <Environment preset="studio" environmentIntensity={.7} />
      <EnvironmentReady onReady={onReady} />
    </Suspense></EnvironmentBoundary>}
    <group>
      <RoundedBox args={[4.6, .13, 4.6]} position={[0, -.65, 0]} radius={.07} smoothness={4} receiveShadow><meshStandardMaterial color="#c5b794" roughness={1} /></RoundedBox>
      <Island />
      <RoundedBox args={[4.6, 1.2, 4.6]} radius={.12} smoothness={4}>
        {/* 입력 waterColor가 이 재질의 color로 전달된다. 수면 시뮬레이션은 아직 없다. */}
        <MeshTransmissionMaterial color={waterColor} transmission={1} thickness={1.2} ior={1.33} roughness={.08} chromaticAberration={0} anisotropicBlur={0} distortion={0} temporalDistortion={0} samples={4} resolution={256} />
      </RoundedBox>
    </group>
    <OrbitControls target={[0, .55, 0]} enablePan={false} minDistance={8} maxDistance={18} minPolarAngle={.25} maxPolarAngle={Math.PI * .47} enableDamping={false} />
  </>
}

export default function App() {
  // 입력: Leva 색상 값 → 처리: waterColor → 화면: 물 블록 재질 색상.
  const [{ waterColor }, set] = useControls(() => ({ waterColor: { label: '물 색상', value: PALETTES[0].hex } }), [])
  const [envState, setEnvState] = useState<'loading' | 'ready' | 'fallback'>('loading')
  const [cameraKey, setCameraKey] = useState(0)
  const ready = useCallback(() => setEnvState(state => state === 'loading' ? 'ready' : state), [])
  const envError = useCallback(() => setEnvState('fallback'), [])
  useEffect(() => {
    if (envState !== 'loading') return
    const timer = window.setTimeout(() => setEnvState('fallback'), 12000)
    return () => window.clearTimeout(timer)
  }, [envState])
  const envMessage = envState === 'ready' ? 'studio 환경 조명 사용 중' : envState === 'fallback' ? '기본 조명 사용 중 · 환경 프리셋을 불러오지 못했어요' : 'studio 환경 조명 불러오는 중 · 기본 조명으로도 사용 가능'
  return <main className="app">
    <section className="scene-area" aria-label="미니어처 섬의 3D 화면">
      <header className="scene-heading"><p className="eyebrow">MINIATURE ISLAND / STARTER 01</p><h1>작은 섬의 첫 번째 색</h1><p>기본 3D 장면에서 물 색상 하나 바꾸기</p></header>
      <div className="canvas-wrap"><SceneBoundary><Canvas key={cameraKey} shadows dpr={[1, 1.5]} camera={{ position: [9.2, 8, 10.7], fov: 30, near: .1, far: 80 }} gl={{ antialias: true, alpha: false }} fallback={<div className="canvas-fallback">이 브라우저에서 WebGL을 사용할 수 없어요. 다른 브라우저에서 열어 보기.</div>}>
        <Scene waterColor={waterColor} environmentEnabled={envState !== 'fallback'} onReady={ready} onError={envError} />
      </Canvas></SceneBoundary></div>
      <div className="scene-bottom"><p>드래그: 시점 확인 · 스크롤: 거리 조절</p><button className="text-button" onClick={() => setCameraKey(key => key + 1)}>처음 구도로</button></div>
    </section>
    <aside className="panel" aria-labelledby="control-title">
      <p className="eyebrow">ONE INPUT → ONE CHANGE</p><h2 id="control-title">물 색상 조절</h2><p className="lead">같은 섬을 유지하고 <br />바다의 분위기만 바꿔 보기.</p>
      <div className="leva-wrap"><Leva fill titleBar={false} hideCopyButton theme={{ colors: { elevation1: '#f7f6ef', elevation2: '#eeeee4', elevation3: '#dddcd0', accent1: '#376958', accent2: '#376958', accent3: '#285245', highlight1: '#626b61', highlight2: '#374d40', highlight3: '#233c30' }, sizes: { controlWidth: '130px' }, radii: { xs: '3px', sm: '5px', lg: '7px' } }} /></div>
      <fieldset className="presets"><legend>빠른 색상 선택</legend>{PALETTES.map(color => <label key={color.hex} className="preset"><input type="radio" name="water-color" value={color.hex} checked={waterColor.toLowerCase() === color.hex} onChange={() => set({ waterColor: color.hex })} /><span className="swatch" style={{ backgroundColor: color.hex }} /><span>{color.name}</span></label>)}</fieldset>
      <p className="value" aria-live="polite">현재 물 색상 <strong>{waterColor}</strong></p>
      <div className="instruction"><span>오늘의 확인</span><p>색 바꾸기 → 물 블록 확인 →<br />어떤 느낌이 달라졌는지 적기</p></div>
      <p className="environment-status" role="status">{envMessage}</p>
      <details className="scope"><summary>이 시작 프로젝트의 범위</summary><p>코드로 만든 섬·해변·바위·나무와 투명한 물 블록, Leva 색상 조절을 제공해요. 수면은 정지 상태.</p><p>GPU 높이장, 젤리 변형, 코스틱, AO, 피사계 심도, 자동 품질 조절은 아직 구현하지 않았어요. 전체 프롬프트의 완성본이 아닌 공통 출발점이에요.</p><p>studio 프리셋은 외부 HDR 파일을 읽어요. 실패하면 기본 조명으로 이어가며, 인터넷이 없으면 반사와 물 표현이 다르게 보여요.</p></details>
      <p className="local-note">로컬 실행 · 모델 파일·유료 API 없음<br />색상은 저장되지 않음 · 새로 열면 초기화</p>
    </aside>
  </main>
}
