STUDIO PENUMBRA — 기존 MAXScript 6종

Max > Scripting > Run Script에서 원하는 .ms를 실행하세요.
Qt / Python 버전은 별도 다운로드입니다.
Max 2025 이하에서는 이 기존판을 사용하세요. 모든 과거 버전에서 검증되었다는 의미는 아닙니다.
